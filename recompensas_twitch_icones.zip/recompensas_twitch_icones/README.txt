Pacote de icones para recompensas da Twitch

Estrutura:
- upload_por_recompensa: cada pasta tem os 3 PNGs da recompensa.
- upload_por_tamanho: todos os icones separados por tamanho.
- preview_catalogo.png: imagem para conferir o conjunto antes do upload.
- manifest.json: lista das recompensas e arquivos gerados.

Tamanhos gerados:
- 28x28 PNG transparente
- 56x56 PNG transparente
- 112x112 PNG transparente

Maior arquivo PNG: 20277 bytes. O limite da Twitch para recompensa e 25 KB por arquivo.

Visual usado como base:
- moeda dourada dos pontos do canal
- brilho e contorno dos distintivos de inscrito
- linguagem simples de emote, para continuar legivel em 28 px
